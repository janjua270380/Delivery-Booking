export  interface Address {
  name: string;
  address: string;
  street?: string;
  city?: string;
  town?: string;
  county?: string;
  building?: string;
  postcode: string;
}

export interface Price {
  base: number;
  vat: number;
  total: number;
}

export interface BookingData {
  id: string;
  collection: Address;
  delivery: Address;
  selectedDate: string;
  isUrgent: boolean;
  vehicleType: 'bike' | 'van';
  price: Price;
  bookingDate: string;
  userId: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  modifiableUntil: string;
  canModify: boolean;
}
 