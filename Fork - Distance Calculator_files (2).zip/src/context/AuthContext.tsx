import  React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  company?: string;
  avatar?: string;
  isAdmin?: boolean;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (name: string, email: string, password: string, company?: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for saved user in localStorage on initial load
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }

    // Create a default user if no users are registered yet
    const usersStr = localStorage.getItem('registeredUsers');
    if (!usersStr || JSON.parse(usersStr).length === 0) {
      // Create a demo user and admin
      const defaultUsers = [
        {
          id: 'demo1',
          name: 'Demo User',
          email: 'demo@example.com',
          password: 'password',
          company: 'Demo Company Ltd',
          registeredAt: new Date().toISOString()
        },
        {
          id: 'admin1',
          name: 'Admin User',
          email: 'admin@example.com',
          password: 'admin123',
          company: 'Delivery Company Ltd',
          registeredAt: new Date().toISOString()
        }
      ];
      localStorage.setItem('registeredUsers', JSON.stringify(defaultUsers));
      console.log('Default users created:', defaultUsers);
    }

    setIsLoading(false);
  }, []);

  // For demo, we'll use a mock login function
  const login = async (email: string, password: string) => {
    setIsLoading(true);
    
    try {
      // This is just for demo, in a real app we'd make an API call
      // Simulate network request
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Check if this email is already registered
      const usersStr = localStorage.getItem('registeredUsers');
      const users = usersStr ? JSON.parse(usersStr) : [];
      const existingUser = users.find((u: any) => u.email === email);
      
      if (!existingUser) {
        throw new Error('User not found. Please register first.');
      }
      
      // Admin account
      if (email === 'admin@example.com') {
        const adminUser = {
          id: 'admin1',
          name: 'Admin User',
          email: 'admin@example.com',
          company: 'Delivery Company Ltd',
          avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36',
          isAdmin: true
        };
        setUser(adminUser);
        localStorage.setItem('user', JSON.stringify(adminUser));
      } else {
        // Regular users
        const mockUser: User = {
          id: existingUser.id,
          name: existingUser.name,
          email: existingUser.email,
          company: existingUser.company,
          avatar: `https://avatars.dicebear.com/api/initials/${encodeURIComponent(existingUser.name)}.svg`,
          isAdmin: false
        };
        
        setUser(mockUser);
        localStorage.setItem('user', JSON.stringify(mockUser));
      }
    } catch (error) {
      console.error('Login error:', error);
      throw new Error((error as Error).message || 'Invalid credentials. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (name: string, email: string, password: string, company?: string) => {
    setIsLoading(true);
    
    try {
      // Simulate network request
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Check if the email is already registered
      const usersStr = localStorage.getItem('registeredUsers');
      const users = usersStr ? JSON.parse(usersStr) : [];
      
      if (users.some((user: any) => user.email === email)) {
        throw new Error('This email is already registered. Please log in instead.');
      }
      
      // Generate a unique ID
      const id = Math.random().toString(36).substr(2, 9);
      
      // Create the new user
      const newUser = {
        id,
        name,
        email,
        company,
        password, // In a real app, this would be hashed
        registeredAt: new Date().toISOString()
      };
      
      // Save the user to "database"
      const updatedUsers = [...users, newUser];
      localStorage.setItem('registeredUsers', JSON.stringify(updatedUsers));
      
      // Now create the user object to return (without password)
      const userObject: User = {
        id,
        name,
        email,
        company,
        avatar: `https://avatars.dicebear.com/api/initials/${encodeURIComponent(name)}.svg`,
        isAdmin: false
      };
      
      setUser(userObject);
      localStorage.setItem('user', JSON.stringify(userObject));
    } catch (error) {
      console.error('Registration error:', error);
      throw new Error((error as Error).message || 'Registration failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
    // Don't remove deliveryBookings from localStorage anymore
    // This allows admin to see all bookings even after users log out
  };

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      isAdmin: !!user?.isAdmin,
      isLoading,
      login,
      logout,
      register
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
 