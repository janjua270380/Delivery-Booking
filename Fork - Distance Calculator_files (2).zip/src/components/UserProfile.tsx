import  { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { User, Building, Mail, LogOut, AlertCircle, Shield } from 'lucide-react';

interface UserProfileProps {
  onClose: () => void;
}

export function UserProfile({ onClose }: UserProfileProps) {
  const { user, logout } = useAuth();
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  
  const handleLogout = () => {
    setIsLoggingOut(true);
    setTimeout(() => {
      logout();
      setIsLoggingOut(false);
      onClose();
    }, 500);
  };
  
  if (!user) return null;

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
      <div className="text-center">
        <div className="relative inline-block">
          <img 
            src={user.avatar || `https://images.unsplash.com/photo-1502823403499-6ccfcf4fb453`}
            alt={user.name}
            className="w-24 h-24 rounded-full object-cover mx-auto"
          />
          <div className="absolute bottom-0 right-0 bg-green-500 w-5 h-5 rounded-full border-2 border-white"></div>
          
          {user.isAdmin && (
            <div className="absolute -top-2 -right-2 bg-green-600 text-white p-1 rounded-full border-2 border-white">
              <Shield className="w-5 h-5" />
            </div>
          )}
        </div>
        
        <h2 className="text-xl font-bold text-gray-800 mt-4">{user.name}</h2>
        
        <div className="mt-2 flex justify-center space-x-4 text-sm text-gray-500">
          <div className="flex items-center">
            <Mail className="w-4 h-4 mr-1" />
            {user.email}
          </div>
          
          {user.isAdmin && (
            <div className="flex items-center text-green-600 font-medium">
              <Shield className="w-4 h-4 mr-1" />
              Admin
            </div>
          )}
        </div>
      </div>
      
      <div className="mt-6 space-y-4">
        <div className="bg-gray-50 p-4 rounded-md">
          <h3 className="font-medium text-gray-700 flex items-center gap-2 mb-2">
            <Building className="w-4 h-4 text-blue-600" />
            Company Information
          </h3>
          
          <p className="text-sm text-gray-600">
            {user.company || 'Personal Account'}
          </p>
        </div>
        
        <div className="bg-blue-50 p-4 rounded-md">
          <h3 className="font-medium text-blue-800 flex items-center gap-2 mb-2">
            <AlertCircle className="w-4 h-4" />
            Demo Account
          </h3>
          
          <p className="text-sm text-blue-700">
            This is a demonstration account. In a production environment, you would have access to account settings, payment methods, and delivery preferences.
            {user.isAdmin && (
              <span className="block mt-2 font-medium">
                As an admin, you have access to all bookings from all users.
              </span>
            )}
          </p>
        </div>
      </div>
      
      <div className="mt-6 flex justify-between items-center">
        <button
          onClick={onClose}
          className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 text-sm hover:bg-gray-50"
        >
          Close
        </button>
        
        <button
          onClick={handleLogout}
          disabled={isLoggingOut}
          className="flex items-center gap-1 px-4 py-2 bg-red-600 text-white rounded-md text-sm hover:bg-red-700 disabled:bg-red-400"
        >
          {isLoggingOut ? (
            <>
              <div className="w-4 h-4 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
              Logging out...
            </>
          ) : (
            <>
              <LogOut className="w-4 h-4" />
              Logout
            </>
          )}
        </button>
      </div>
    </div>
  );
}
 