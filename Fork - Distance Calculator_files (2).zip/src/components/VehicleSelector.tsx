import  { CheckCircle } from 'lucide-react';

interface VehicleSelectorProps {
  selectedVehicle: 'bike' | 'van' | null;
  onVehicleSelect: (vehicle: 'bike' | 'van') => void;
}

export function VehicleSelector({ selectedVehicle, onVehicleSelect }: VehicleSelectorProps) {
  return (
    <div className="bg-white p-4 rounded-lg">
      <h3 className="text-lg font-semibold text-gray-800 mb-3">Select Vehicle Type</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div 
          className={`relative cursor-pointer rounded-lg border-2 overflow-hidden transition-all
            ${selectedVehicle === 'bike' 
              ? 'border-blue-500 ring-2 ring-blue-200' 
              : 'border-gray-200 hover:border-blue-200'}`}
          onClick={() => onVehicleSelect('bike')}
        >
          <div className="aspect-video relative overflow-hidden bg-gray-100">
            <img 
              src="https://images.unsplash.com/photo-1560181251-40ede245f033?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxkZWxpdmVyeSUyMHZhbiUyMFVLJTIwY291cmllciUyMHNlcnZpY2V8ZW58MHx8fHwxNzQzNzE5MjU2fDA&ixlib=rb-4.0.3&fit=fillmax&h=200&w=300"
              alt="Bike courier"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          </div>
          
          <div className="p-3">
            <div className="flex justify-between items-center">
              <h4 className="font-medium text-gray-900">Bike Courier</h4>
              {selectedVehicle === 'bike' && (
                <CheckCircle className="w-5 h-5 text-blue-500" />
              )}
            </div>
          </div>
        </div>
        
        <div 
          className={`relative cursor-pointer rounded-lg border-2 overflow-hidden transition-all
            ${selectedVehicle === 'van' 
              ? 'border-blue-500 ring-2 ring-blue-200' 
              : 'border-gray-200 hover:border-blue-200'}`}
          onClick={() => onVehicleSelect('van')}
        >
          <div className="aspect-video relative overflow-hidden bg-gray-100">
            <img 
              src="https://images.unsplash.com/photo-1423248515266-98acb914c861?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwzfHxkZWxpdmVyeSUyMHZhbiUyMFVLJTIwY291cmllciUyMHNlcnZpY2V8ZW58MHx8fHwxNzQzNzE5MjU2fDA&ixlib=rb-4.0.3&fit=fillmax&h=200&w=300"
              alt="Delivery van on road"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          </div>
          
          <div className="p-3">
            <div className="flex justify-between items-center">
              <h4 className="font-medium text-gray-900">Delivery Van</h4>
              {selectedVehicle === 'van' && (
                <CheckCircle className="w-5 h-5 text-blue-500" />
              )}
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-3 text-xs text-gray-500">
        * Vehicle selection may affect pricing and estimated delivery times
      </div>
    </div>
  );
}
 