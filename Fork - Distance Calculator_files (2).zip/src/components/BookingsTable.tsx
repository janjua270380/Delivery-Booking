import  { useState } from 'react';
import { getBookings, updateBooking } from '../utils/storage';
import { Database, Eye, EyeOff, ArrowLeft, Download, Shield, CheckCircle, Clock, XCircle, Edit, User, Bike, Truck } from 'lucide-react';
import { AdminCustomersList } from './AdminCustomersList';

interface BookingsTableProps {
  onBack: () => void;
}

export function BookingsTable({ onBack }: BookingsTableProps) {
  const [showAll, setShowAll] = useState(false);
  const [sortField, setSortField] = useState<string>('timestamp');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [selectedBooking, setSelectedBooking] = useState<string | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateStatus, setUpdateStatus] = useState<{success?: string, error?: string} | null>(null);
  const [showCustomers, setShowCustomers] = useState(false);
  
  // Get all bookings from localStorage
  const bookings = getBookings();
  
  // Sort bookings based on current sort field and direction
  const sortedBookings = [...bookings].sort((a, b) => {
    let valueA = a[sortField];
    let valueB = b[sortField];
    
    // Special handling for dates
    if (sortField === 'timestamp' || sortField === 'modifiableUntil') {
      valueA = new Date(valueA).getTime();
      valueB = new Date(valueB).getTime();
    }
    
    if (valueA < valueB) return sortDirection === 'asc' ? -1 : 1;
    if (valueA > valueB) return sortDirection === 'asc' ? 1 : -1;
    return 0;
  });
  
  const displayBookings = showAll ? sortedBookings : sortedBookings.slice(0, 10);
  
  // Function to export bookings as CSV
  const exportCSV = () => {
    if (bookings.length === 0) return;
    
    // Get all keys from the first booking for headers
    const headers = Object.keys(bookings[0]);
    
    // Create CSV content
    let csvContent = headers.join(',') + '\n';
    
    bookings.forEach(booking => {
      const row = headers.map(header => {
        // Handle values that might contain commas by wrapping in quotes
        let cell = booking[header] || '';
        cell = cell.toString().replace(/"/g, '""'); // Escape quotes
        return `"${cell}"`;
      }).join(',');
      csvContent += row + '\n';
    });
    
    // Create and download the file
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'delivery_bookings.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Function to handle column sorting
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };
  
  // Render sort indicator
  const renderSortIndicator = (field: string) => {
    if (sortField !== field) return null;
    
    return sortDirection === 'asc' 
      ? <span className="ml-1">↑</span> 
      : <span className="ml-1">↓</span>;
  };
  
  // Function to handle booking status update
  const handleStatusChange = async (bookingId: string, newStatus: 'pending' | 'confirmed' | 'cancelled' | 'completed') => {
    setIsUpdating(true);
    setUpdateStatus(null);
    
    try {
      await updateBooking(bookingId, { status: newStatus });
      setUpdateStatus({ success: `Booking successfully updated to ${newStatus}` });
      
      // Update the selected booking if it's open
      if (selectedBooking === bookingId) {
        setSelectedBooking(null);
        setTimeout(() => setSelectedBooking(bookingId), 100);
      }
    } catch (error) {
      setUpdateStatus({ error: `Failed to update booking: ${(error as Error).message}` });
    } finally {
      setIsUpdating(false);
    }
  };
  
  // Function to get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return (
          <span className="px-2 py-1 inline-flex items-center gap-1 text-xs leading-none font-semibold rounded-full bg-blue-100 text-blue-800">
            <Clock className="w-3 h-3" />
            Pending
          </span>
        );
      case 'confirmed':
        return (
          <span className="px-2 py-1 inline-flex items-center gap-1 text-xs leading-none font-semibold rounded-full bg-green-100 text-green-800">
            <CheckCircle className="w-3 h-3" />
            Confirmed
          </span>
        );
      case 'completed':
        return (
          <span className="px-2 py-1 inline-flex items-center gap-1 text-xs leading-none font-semibold rounded-full bg-purple-100 text-purple-800">
            <CheckCircle className="w-3 h-3" />
            Completed
          </span>
        );
      case 'cancelled':
        return (
          <span className="px-2 py-1 inline-flex items-center gap-1 text-xs leading-none font-semibold rounded-full bg-red-100 text-red-800">
            <XCircle className="w-3 h-3" />
            Cancelled
          </span>
        );
      default:
        return (
          <span className="px-2 py-1 inline-flex items-center gap-1 text-xs leading-none font-semibold rounded-full bg-gray-100 text-gray-800">
            {status || 'Unknown'}
          </span>
        );
    }
  };

  // Function to format address without repetition
  const formatAddress = (booking: any, type: 'collection' | 'delivery') => {
    const prefix = type === 'collection' ? 'collection' : 'delivery';
    
    return (
      <>
        <span className="font-medium">{booking[`${prefix}Name`]}</span><br />
        {booking[`${prefix}Building`] && `${booking[`${prefix}Building`]}, `}
        {booking[`${prefix}Address`]}<br />
        {booking[`${prefix}City`] && `${booking[`${prefix}City`]}, `}
        {booking[`${prefix}County`] && booking[`${prefix}County`] !== booking[`${prefix}City`] && `${booking[`${prefix}County`]}, `}
        {booking[`${prefix}Postcode`]}
      </>
    );
  };
  
  // Function to extract time from date 
  const extractTimeFromDate = (dateString: string) => {
    try {
      // Try to parse the date string
      const date = new Date(dateString);
      
      // Return time in 12-hour format
      return date.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
      });
    } catch (e) {
      // If there's an error parsing the date, just return the original string
      return dateString;
    }
  };

  if (showCustomers) {
    return <AdminCustomersList onBack={() => setShowCustomers(false)} />;
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 space-y-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            aria-label="Go back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
            <Shield className="w-6 h-6 text-green-600" />
            Admin Dashboard
          </h2>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={() => setShowCustomers(true)}
            className="flex items-center gap-1 text-sm py-1 px-3 bg-blue-600 text-white hover:bg-blue-700 rounded-md"
          >
            <User className="w-4 h-4" />
            View Customers
          </button>
          
          <button
            onClick={() => setShowAll(!showAll)}
            className="flex items-center gap-1 text-sm py-1 px-3 bg-gray-100 hover:bg-gray-200 rounded-md"
          >
            {showAll ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            {showAll ? 'Show Less' : 'Show All'}
          </button>
          
          <button
            onClick={exportCSV}
            disabled={bookings.length === 0}
            className="flex items-center gap-1 text-sm py-1 px-3 bg-green-600 text-white hover:bg-green-700 rounded-md disabled:bg-gray-300 disabled:text-gray-500"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>
      </div>
      
      <div className="bg-blue-50 p-4 rounded-md mb-4">
        <div className="flex items-center gap-2 text-blue-800">
          <Database className="w-5 h-5 text-blue-600 flex-shrink-0" />
          <div>
            <p className="font-medium">Bookings Dashboard</p>
            <p className="text-sm mt-1">
              You have access to all bookings from all users. In a production environment, this data would be synced with your Google Sheets.
            </p>
          </div>
        </div>
      </div>
      
      {updateStatus && (
        <div className={`p-3 rounded-md ${updateStatus.error ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'}`}>
          <p className="text-sm">{updateStatus.error || updateStatus.success}</p>
        </div>
      )}
      
      {bookings.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('timestamp')}
                >
                  Timestamp {renderSortIndicator('timestamp')}
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('vehicleType')}
                >
                  Vehicle {renderSortIndicator('vehicleType')}
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('collectionName')}
                >
                  Collection {renderSortIndicator('collectionName')}
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('deliveryName')}
                >
                  Delivery {renderSortIndicator('deliveryName')}
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('date')}
                >
                  Collection Date & Time {renderSortIndicator('date')}
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('status')}
                >
                  Status {renderSortIndicator('status')}
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('totalPrice')}
                >
                  Total {renderSortIndicator('totalPrice')}
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {displayBookings.map((booking, index) => (
                <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {booking.timestamp}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-900">
                      {booking.vehicleType === 'bike' ? (
                        <Bike className="w-4 h-4 text-blue-600 mr-1" />
                      ) : (
                        <Truck className="w-4 h-4 text-blue-600 mr-1" />
                      )}
                      {booking.vehicleType === 'bike' ? 'Bike' : 'Van'}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{booking.collectionName}</div>
                    <div className="text-sm text-gray-500">{booking.collectionPostcode}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{booking.deliveryName}</div>
                    <div className="text-sm text-gray-500">{booking.deliveryPostcode}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {booking.date}
                    <div className="text-xs text-blue-600">
                      {extractTimeFromDate(booking.deliveryTime || booking.date)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {getStatusBadge(booking.status || (booking.isUrgent === 'Yes' ? 'urgent' : 'standard'))}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    £{booking.totalPrice}
                    {booking.isUrgent === 'Yes' && (
                      <span className="text-xs text-amber-600 block mt-1">Urgent</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex gap-2">
                      <button 
                        onClick={() => setSelectedBooking(selectedBooking === booking.bookingId ? null : booking.bookingId)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      
                      <button
                        onClick={() => setSelectedBooking(booking.bookingId)}
                        className="text-gray-600 hover:text-gray-900"
                        title="Edit/Manage Booking"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="text-center py-10">
          <Database className="w-12 h-12 mx-auto text-gray-300 mb-3" />
          <p className="text-gray-500">No bookings saved yet</p>
          <p className="text-sm text-gray-400 mt-1">
            When clients make bookings, they will appear here
          </p>
        </div>
      )}
      
      {selectedBooking && (() => {
        const booking = bookings.find(b => b.bookingId === selectedBooking);
        if (!booking) return null;
        
        return (
          <div className="mt-6 bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <span>Booking Details</span>
              <div className="flex items-center gap-1 text-sm bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">
                {booking.vehicleType === 'bike' ? (
                  <Bike className="w-3 h-3" />
                ) : (
                  <Truck className="w-3 h-3" />
                )}
                {booking.vehicleType === 'bike' ? 'Bike Courier' : 'Delivery Van'}
              </div>
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Collection Address</h4>
                  <p className="text-sm">
                    {formatAddress(booking, 'collection')}
                  </p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Pricing</h4>
                  <p className="text-sm">
                    Base Price: £{booking.basePrice}<br />
                    VAT (20%): £{booking.vat}<br />
                    <span className="font-medium">Total: £{booking.totalPrice}</span>
                  </p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Customer</h4>
                  <p className="text-sm">
                    User ID: {booking.userId || 'Not recorded'}<br />
                    Date Booked: {booking.timestamp || 'Unknown'}<br />
                    Modifiable Until: {booking.modifiableUntil || 'Not applicable'}
                  </p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Delivery Address</h4>
                  <p className="text-sm">
                    {formatAddress(booking, 'delivery')}
                  </p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Collection Info</h4>
                  <p className="text-sm">
                    Date: {booking.date}<br />
                    Time: {extractTimeFromDate(booking.deliveryTime || booking.date)}<br />
                    Urgent: {booking.isUrgent}<br />
                    Vehicle: {booking.vehicleType === 'bike' ? 'Bike Courier' : 'Delivery Van'}<br />
                    Status: {booking.status || 'Not recorded'}
                  </p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Booking ID</h4>
                  <p className="text-sm font-mono bg-gray-100 p-2 rounded">
                    {booking.bookingId || 'Unknown'}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="mt-6 border-t border-gray-200 pt-4">
              <h4 className="text-sm font-medium text-gray-700 mb-3">Admin Actions</h4>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => handleStatusChange(booking.bookingId, 'pending')}
                  disabled={isUpdating || booking.status === 'pending'}
                  className="px-3 py-1 text-xs bg-blue-100 text-blue-800 rounded-md hover:bg-blue-200 disabled:opacity-50"
                >
                  <Clock className="w-3 h-3 inline mr-1" />
                  Mark as Pending
                </button>
                
                <button
                  onClick={() => handleStatusChange(booking.bookingId, 'confirmed')}
                  disabled={isUpdating || booking.status === 'confirmed'}
                  className="px-3 py-1 text-xs bg-green-100 text-green-800 rounded-md hover:bg-green-200 disabled:opacity-50"
                >
                  <CheckCircle className="w-3 h-3 inline mr-1" />
                  Confirm Booking
                </button>
                
                <button
                  onClick={() => handleStatusChange(booking.bookingId, 'completed')}
                  disabled={isUpdating || booking.status === 'completed'}
                  className="px-3 py-1 text-xs bg-purple-100 text-purple-800 rounded-md hover:bg-purple-200 disabled:opacity-50"
                >
                  <CheckCircle className="w-3 h-3 inline mr-1" />
                  Mark as Completed
                </button>
                
                <button
                  onClick={() => handleStatusChange(booking.bookingId, 'cancelled')}
                  disabled={isUpdating || booking.status === 'cancelled'}
                  className="px-3 py-1 text-xs bg-red-100 text-red-800 rounded-md hover:bg-red-200 disabled:opacity-50"
                >
                  <XCircle className="w-3 h-3 inline mr-1" />
                  Cancel Booking
                </button>
                
                {isUpdating && (
                  <span className="px-3 py-1 text-xs bg-gray-100 text-gray-700 rounded-md">
                    <div className="w-3 h-3 border-t-2 border-b-2 border-gray-700 rounded-full animate-spin inline-block mr-1"></div>
                    Updating...
                  </span>
                )}
              </div>
            </div>
          </div>
        );
      })()}
      
      <div className="mt-6 flex justify-between items-center">
        <button
          onClick={onBack}
          className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
        >
          Back to Dashboard
        </button>
        
        <button
          onClick={exportCSV}
          disabled={bookings.length === 0}
          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:bg-gray-300 disabled:text-gray-500"
        >
          <Download className="w-4 h-4" />
          Export to Excel/CSV
        </button>
      </div>
    </div>
  );
}
 